-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 02 2023 г., 22:21
-- Версия сервера: 10.8.4-MariaDB
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `portalgosproblem`
--

-- --------------------------------------------------------

--
-- Структура таблицы `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `название` varchar(255) NOT NULL,
  `описание` text NOT NULL,
  `категория` varchar(50) NOT NULL,
  `фото` varchar(255) NOT NULL,
  `время_добавления` datetime NOT NULL,
  `статус` varchar(50) NOT NULL DEFAULT 'Новая',
  `id_user` int(10) UNSIGNED NOT NULL,
  `фото_пруф` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `application`
--

INSERT INTO `application` (`id`, `название`, `описание`, `категория`, `фото`, `время_добавления`, `статус`, `id_user`, `фото_пруф`) VALUES
(9, 'ХУЙ', 'fghbg', '3', 'uploads/644ff68b13a5b.jpg', '2023-05-01 20:27:39', 'Решена', 15, 'uploads/644ffd52d96ba.jpg'),
(10, 'sdfgsdfg', 'sdfgsdfg', '2', 'uploads/64500baf4db23.jpg', '2023-05-01 21:57:51', 'Решена', 15, 'uploads/6450245d662ad.jpg'),
(11, 'ХУЙ ', 'ХУЙПАВЫП', '3', 'uploads/64502ae487e92.jpg', '2023-05-02 00:11:00', 'Решена', 15, 'uploads/64502b18d77a0.jpg'),
(12, 'ЖОПА', 'ААААААААААА', '4', 'uploads/64502aee60f3c.jpg', '2023-05-02 00:11:10', 'Решена', 15, 'uploads/64502b2142fc0.jpg'),
(14, 'Тестик', 'УУ Фейс', '4', 'uploads/64514ba99c9bd.jpg', '2023-05-02 20:43:05', 'Решена', 15, 'uploads/645156b23da59.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `application_status`
--

CREATE TABLE `application_status` (
  `id_application_status` int(11) NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `application_status`
--

INSERT INTO `application_status` (`id_application_status`, `status`) VALUES
(1, 'Новая'),
(2, 'Решена'),
(3, 'Отклонена');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id_categories` int(11) NOT NULL,
  `categories` varchar(100) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id_categories`, `categories`) VALUES
(1, 'Уборка мусора '),
(2, 'Ремонт дорог'),
(3, 'Ремонт'),
(4, 'Уборка');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fio` varchar(255) NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `fio`, `login`, `email`, `password`) VALUES
(1, 'Старых Алексей Старович', 'stariy', 'org@be.com', '1234'),
(4, '56u56u', '555', 'artemsteam34@bk.ru', '1234'),
(15, '56u56u', 'ded', 'sonyakapinskaya@gmail.com', '12345'),
(20, 'edgerg', 'lol', 'test@test.com', 'test'),
(22, 'kak', 'kak', 'rustam.mansurov208@mail.ru', '12345'),
(24, 'Новых Алексей Старович', 'zoro', 'zoro@mail.com', 'kek123'),
(26, 'Мамикс Максм Бахарев', 'baks', 'baks@suka.re', 'b123'),
(28, 'Богданов Петр Ебланович', 'petya', 'petek@sin.xuyni', 'qwerty'),
(29, 'Мини Дианка Ром', 'didi', 'didine@zig.hay', 'didi510'),
(31, 'Александр Дедов Переезд', 'aleks', 'dcdsv@lp.com', '1234'),
(37, 'Аристов ', 'kizaru', 'kiza@tutu.com', 'k1234'),
(41, 'Аристов ', 'rgerg', 'kiergreza@tutuy.com', '1234'),
(42, 'Дедов Данил Ромович', 'qwrfqwefqwefg', 'rustam.manwefwefsurov208@mail.ru', '1234'),
(44, 'Дедов Данил Ромович', 'adminefwe', 'orgwefwef@be.com', '123'),
(45, 'Дедов Данил Ромович', 'adminergerg', 'rustam.manswefwefurov208@mail.ru', '12'),
(46, 'хуй', 'wefwefwe', 'rustam.mawefwefwefwefwefnsurov208@mail.ru', '123'),
(47, 'хуй', 'adminрпрп', 'rusxcastam.mansurov208@mail.ru', '123'),
(49, 'ergerger', 'qwqwr', 'org@bewewfwefw.com', '12'),
(50, '56u56u', 'dfgdfgdfgdf', 'sonyakapinskdgdfaya@gmail.com', '123'),
(52, '56u56uwqdqw', 'dfgdfgdfgdfqwdqw', 'sonyakapinskdgdfaya@gmqwdail.com', '123'),
(54, 'Старых Алексей Старовичwefwefwe', 'rerg', 'artemswewewefedeteam34@bk.ru', '123'),
(55, 'asd', 'vasya', 'fak@bk.ru', '123'),
(57, 'Киров Юбилей Облачный', 'kirov', 'kir34@bk.ru', '1234'),
(58, 'Старых Алексей Старовdwwич', 'adminqwdqwd', 'sonyakapinskd1aya@gmail.com', '123'),
(59, 'Я пизда нет пизды', 'pizda', 'pizda34@bk.ru', '1234');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `application_status`
--
ALTER TABLE `application_status`
  ADD PRIMARY KEY (`id_application_status`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_categories`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `application_status`
--
ALTER TABLE `application_status`
  MODIFY `id_application_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id_categories` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
